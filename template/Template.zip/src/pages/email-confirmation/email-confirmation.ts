import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';


@IonicPage()
@Component({
  selector: 'page-email-confirmation',
  templateUrl: 'email-confirmation.html',
})
export class EmailConfirmationPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
   
  }

 

}
